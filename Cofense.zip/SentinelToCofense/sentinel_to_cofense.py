"""This file contains implementation of microsoft sentinel threat intelligence indicator fetching
and creating cofense indicator."""
import time
import json
import inspect
from ..SharedCode.consts import (
    AZURE_SUBSCRIPTION_ID,
    AZURE_RESOURCE_GROUP,
    AZURE_WORKSPACE_NAME,
    LOGS_STARTS_WITH,
    CONNECTION_STRING,
    QUERY_SENTINEL_INDICATORS_URL,
    QUERY_SENTINEL_PAGESIZE,
    COFENSE_POST_INDICATOR_URL,
    SENTINELTOCOFENSE,
    COFENSE_429_SLEEP,
    COFENSE_UPDATE_INDICATOR_URL,
    SENTINEL_429_SLEEP,
    SENTINEL_SOURCE_PREFIX,
    COFENSE_SOURCE_PREFIX,
)
from ..SharedCode.logger import applogger
from ..SharedCode.cofense_exception import CofenseException
from ..SharedCode.state_manager import StateManager
from ..SharedCode.utils import auth_sentinel, make_rest_call, auth_cofense, create_proxy


class MicrosoftSentinel:
    """This class contains methods to get threat intelligence indicator from Microsoft Sentinel."""

    def __init__(self) -> None:
        """Initialize instance variable for class."""
        __method_name = inspect.currentframe().f_code.co_name
        applogger.info(
            "{}(method={}) : {} : "
            "Started execution of posting indicators into Cofense Triage from "
            "Microsoft Sentinel Threat Intelligence.".format(
                LOGS_STARTS_WITH,
                __method_name,
                SENTINELTOCOFENSE,
            )
        )
        self.bearer_token = auth_sentinel(SENTINELTOCOFENSE)
        self.sentinel_checkpoint_state = StateManager(
            connection_string=CONNECTION_STRING,
            file_path="sentinel_checkpoint",
        )
        sentinel_checkpoint_data = self.sentinel_checkpoint_state.get()
        if sentinel_checkpoint_data is not None:
            self.sentinel_skiptoken = sentinel_checkpoint_data
            applogger.debug(
                "{}(method={}) : {} : "
                "Last checkpoint is : {}".format(
                    LOGS_STARTS_WITH,
                    __method_name,
                    SENTINELTOCOFENSE,
                    self.sentinel_skiptoken,
                )
            )
        else:
            applogger.debug(
                "{}(method={}) : {} : "
                "No checkpoint found. Fetching data from starting.".format(
                    LOGS_STARTS_WITH,
                    __method_name,
                    SENTINELTOCOFENSE,
                )
            )
            self.sentinel_skiptoken = ""

    def get_indicators_from_sentinel(self):
        """To get indicators from Microsoft Sentinel threat intelligence.

        Raises:
            CofenseException: Custom exception raises while getting exception.
        """
        try:
            __method_name = inspect.currentframe().f_code.co_name
            applogger.info(
                "{}(method={}) : {} : "
                "Started fetching indicators from Microsoft Sentinel Threat Intelligence.".format(
                    LOGS_STARTS_WITH,
                    __method_name,
                    SENTINELTOCOFENSE,
                )
            )
            retry_count_429 = 0
            retry_count_401 = 0
            while retry_count_429 < 3 and retry_count_401 < 3:
                query_indicator_url = QUERY_SENTINEL_INDICATORS_URL.format(
                    subscriptionId=AZURE_SUBSCRIPTION_ID,
                    resourceGroupName=AZURE_RESOURCE_GROUP,
                    workspaceName=AZURE_WORKSPACE_NAME,
                )
                headers = {
                    "Content-Type": "application/json",
                    "Authorization": "Bearer {}".format(self.bearer_token),
                }
                body = {
                    "pageSize": QUERY_SENTINEL_PAGESIZE,
                    "sortBy": [
                        {"itemKey": "lastUpdatedTimeUtc", "sortOrder": "ascending"}
                    ],
                    "skipToken": self.sentinel_skiptoken,
                }
                get_indicator_response = make_rest_call(
                    url=query_indicator_url,
                    method="POST",
                    azure_function_name=SENTINELTOCOFENSE,
                    payload=json.dumps(body),
                    headers=headers,
                )

                # If response status code is 200 to 299.
                if (
                    get_indicator_response.status_code >= 200
                    and get_indicator_response.status_code <= 299
                ):
                    sentinel_indicator_json = json.loads(get_indicator_response.text)
                    sentinel_indicator_json_list = sentinel_indicator_json.get(
                        "value", []
                    )
                    # Posting indicators into cofense.
                    self.post_indicators(
                        sentinel_json_indicator_list=sentinel_indicator_json_list
                    )

                    # Updating the checkpoint.
                    sentinel_indicator_nextlink = sentinel_indicator_json.get(
                        "nextLink", ""
                    )
                    if (
                        sentinel_indicator_nextlink is not None
                        and sentinel_indicator_nextlink != ""
                    ):
                        self.sentinel_skiptoken = sentinel_indicator_nextlink.split(
                            "$skipToken="
                        )[1]
                        self.sentinel_checkpoint_state.post(self.sentinel_skiptoken)
                        applogger.debug(
                            "{}(method={}) : {} : "
                            "Checkpoint saved : {}".format(
                                LOGS_STARTS_WITH,
                                __method_name,
                                SENTINELTOCOFENSE,
                                self.sentinel_skiptoken,
                            )
                        )
                    else:
                        # checkpoint not found in response. No more data to fetch. Exiting the function app.
                        applogger.info(
                            "{}(method={}) : {}: url: {}, Status Code : {} : "
                            "No more indicators to fetch from Microsoft Sentinel. Exiting the function app.".format(
                                LOGS_STARTS_WITH,
                                __method_name,
                                SENTINELTOCOFENSE,
                                query_indicator_url,
                                get_indicator_response.status_code,
                            )
                        )
                        # Exit from function app.
                        return True

                # response status code is 429.
                elif get_indicator_response.status_code == 429:
                    retry_count_429 += 1
                    applogger.error(
                        "{}(method={}) : {}: url: {}, Status Code : {} : "
                        "Getting 429 from sentinel get indicators api call. Retrying again after {} seconds.".format(
                            LOGS_STARTS_WITH,
                            __method_name,
                            SENTINELTOCOFENSE,
                            query_indicator_url,
                            get_indicator_response.status_code,
                            SENTINEL_429_SLEEP,
                        )
                    )
                    applogger.debug(
                        "{}(method={}) : {}: url: {}, Status Code : {}, Response reason: {}, Response: {} : "
                        "Getting 429 from sentinel get indicators api call. Retry count: {}.".format(
                            LOGS_STARTS_WITH,
                            __method_name,
                            SENTINELTOCOFENSE,
                            query_indicator_url,
                            get_indicator_response.status_code,
                            get_indicator_response.reason,
                            get_indicator_response.text,
                            retry_count_429,
                        )
                    )
                    # sleep for 60 seconds.
                    time.sleep(SENTINEL_429_SLEEP)

                # response is 401, access token is expired.
                elif get_indicator_response.status_code == 401:
                    retry_count_401 = retry_count_401 + 1
                    applogger.error(
                        "{}(method={}) : {} : url: {}, Status Code : {}:  Error Reason: {} : "
                        "Sentinel access token expired, generating new access token.".format(
                            LOGS_STARTS_WITH,
                            __method_name,
                            SENTINELTOCOFENSE,
                            query_indicator_url,
                            get_indicator_response.status_code,
                            get_indicator_response.reason,
                        )
                    )
                    applogger.debug(
                        "{}(method={}) : {} : url: {}, Status Code : {}, Error Reason: {}, Response: {} : Sentinel"
                        " access token expired, generating new access token. Retry count: {}.".format(
                            LOGS_STARTS_WITH,
                            __method_name,
                            SENTINELTOCOFENSE,
                            query_indicator_url,
                            get_indicator_response.status_code,
                            get_indicator_response.reason,
                            get_indicator_response.text,
                            retry_count_401,
                        )
                    )
                    self.bearer_token = auth_sentinel(SENTINELTOCOFENSE)

                # response status code is not 200 to 299, 429 and 401.
                else:
                    applogger.error(
                        "{}(method={}) : {} : url: {}, Status Code : {} : Error while fetching indicators"
                        " from sentinel threat intelligence. Error Reason: {}".format(
                            LOGS_STARTS_WITH,
                            __method_name,
                            SENTINELTOCOFENSE,
                            query_indicator_url,
                            get_indicator_response.status_code,
                            get_indicator_response.reason,
                        )
                    )
                    applogger.debug(
                        "{}(method={}) : {} : url: {}, Status Code : {}, Error Reason: {}, Response: {} :"
                        " Error while fetching indicators from sentinel threat intelligence.".format(
                            LOGS_STARTS_WITH,
                            __method_name,
                            SENTINELTOCOFENSE,
                            query_indicator_url,
                            get_indicator_response.status_code,
                            get_indicator_response.reason,
                            get_indicator_response.text,
                        )
                    )
                    # raise the exception to exit the function app.
                    raise CofenseException(
                        "{}(method={}) : {} : Error while fetching indicators from sentinel threat intelligence."
                        " Error Reason: {}".format(
                            LOGS_STARTS_WITH,
                            __method_name,
                            SENTINELTOCOFENSE,
                            get_indicator_response.reason,
                        )
                    )

            # retry count exceeded.
            applogger.error(
                "{}(method={}) : {} : Max retries exceeded for fetching indicators from sentinel.".format(
                    LOGS_STARTS_WITH,
                    __method_name,
                    SENTINELTOCOFENSE,
                )
            )
            # raising the exception to exit the function app.
            raise CofenseException(
                "{}(method={}) : {} : Max retries exceeded for fetching indicators from sentinel. Error Reason: {}".format(
                    LOGS_STARTS_WITH,
                    __method_name,
                    SENTINELTOCOFENSE,
                    get_indicator_response.reason,
                )
            )

        except CofenseException as error:
            raise CofenseException(error)

    def post_indicators(self, sentinel_json_indicator_list):
        """To post and update the indicators into Cofense Triage.

        Args:
            sentinel_json_indicator_list (JSON List): Sentinel indicators json list.

        Raises:
            CofenseException: Custom exception raises while getting exception.
        """

        try:
            __method_name = inspect.currentframe().f_code.co_name

            cofense_object = CofenseTriage()

            # Initializing state manager for sentinel and cofense indicator id table.
            sentinel_cofense_id_table_state = StateManager(
                connection_string=CONNECTION_STRING,
                file_path="sentinel_cofense_id_table",
            )
            sentinel_cofense_id_table_data = sentinel_cofense_id_table_state.get()

            if sentinel_cofense_id_table_data is not None:
                sentinel_cofense_id_table = json.loads(sentinel_cofense_id_table_data)
            else:
                # if table data is none then initialize the id table.
                sentinel_cofense_id_table = {}

            applogger.debug(
                "{}(method={}) : {} : "
                "Fetched Sentinel Cofense ID table.".format(
                    LOGS_STARTS_WITH,
                    __method_name,
                    SENTINELTOCOFENSE,
                )
            )

            applogger.debug(
                "{}(method={}) : {} : "
                "Started posting and updating indicators into Cofense Triage.".format(
                    LOGS_STARTS_WITH,
                    __method_name,
                    SENTINELTOCOFENSE,
                )
            )
            # posting and updating indicators
            for indicators in sentinel_json_indicator_list:

                # getting indicator source.
                indicator_source = self.get_indicator_source(indicators)

                # getting indicator type.
                sentinel_indicator_pattern_type = indicators.get("properties", "").get(
                    "patternType", None
                )

                # convert sentinel indicator type to cofense indicator type.
                (
                    sentinel_indicator_pattern_type,
                    cofense_indicator_pattern_type,
                ) = self.get_cofense_pattern_type(
                    indicators, sentinel_indicator_pattern_type
                )

                # if indicator source and sentinel indicator pattern type is not as need.
                if (
                    indicator_source is not None
                    and sentinel_indicator_pattern_type is not None
                    and cofense_indicator_pattern_type is not None
                    and sentinel_indicator_pattern_type != "ipv4-addr"
                    and sentinel_indicator_pattern_type != "ipv6-addr"
                ):

                    # if the sentinel indicator name is connected with a cofense id then update the indicator data into cofense triage.
                    sentinel_indicator_name = indicators.get("name", "")
                    if sentinel_cofense_id_table.get(sentinel_indicator_name):
                        # Update the indicator.
                        self.update_indicator(
                            indicators, cofense_object, sentinel_cofense_id_table
                        )

                    # or else create a new indicator into cofense triage and relate the sentinel and cofense id,
                    # into id table.
                    else:

                        # Create indicator into cofense.
                        (
                            post_indicator_status_code,
                            post_response_json,
                        ) = self.create_indicator(
                            indicators,
                            cofense_object,
                            cofense_indicator_pattern_type,
                            indicator_source,
                        )

                        if (
                            post_indicator_status_code >= 200
                            and post_indicator_status_code <= 299
                        ):
                            # getting the cofense triage indicator id.
                            cofense_id = post_response_json.get("data").get("id")

                            # getting sentinel id/name.
                            sentinel_name = indicators.get("name")

                            # updating the sentinel name - cofense id into the id table.
                            sentinel_cofense_id_table[sentinel_name] = cofense_id
                            sentinel_cofense_id_table_state.post(
                                json.dumps(sentinel_cofense_id_table)
                            )

        except CofenseException as error:
            raise CofenseException(error)

    def get_indicator_source(self, indicators):
        """To get the sentinel indicator source.

        Args:
            indicator (JSON Dictionary): Indicator data in json.

        Raises:
            CofenseException: Custom exception raises while getting exception.

        Returns:
            String: Indicator source.
        """
        try:
            indicator_source_temp = indicators.get("properties", "").get("source", None)
            if (
                indicator_source_temp is not None
                and indicator_source_temp.split(":")[0].lower().strip()
                != COFENSE_SOURCE_PREFIX.split(":")[0].lower().strip()
            ):
                return indicator_source_temp
            else:
                return None
        except CofenseException as error:
            raise CofenseException(error)

    def get_cofense_pattern_type(self, indicators, sentinel_indicator_pattern_type):
        """To convert sentinel indicator type to cofense accepted indicator type.

        Args:
            indicator (JSON Dictionary): Indicator data in json.
            cofense_indicator_pattern_type (String): threat type for creating indicator in cofense triage.

        Raises:
            CofenseException: Custom exception raises while getting exception.

        Returns:
            Tuple: return sentinel threat type and cofense threat type.
        """
        try:
            cofense_indicator_pattern_type = None
            # if indicator type is url in sentinel then URL in cofense.
            if sentinel_indicator_pattern_type == "url":
                cofense_indicator_pattern_type = "URL"

            # if indicator type is domain-name in sentinel then Hostname in cofense.
            elif sentinel_indicator_pattern_type == "domain-name":
                cofense_indicator_pattern_type = "Hostname"

            # if indicator type is file in sentinel then MD5 or SHA256 in cofense.
            elif sentinel_indicator_pattern_type == "file":
                sentinel_indicator_pattern = indicators.get("properties", "").get(
                    "pattern", None
                )
                if sentinel_indicator_pattern is not None:
                    sentinel_file_pattern = sentinel_indicator_pattern.split("'")[1]

                    if sentinel_file_pattern == "MD5":
                        cofense_indicator_pattern_type = "MD5"
                    elif sentinel_file_pattern == "SHA-256":
                        cofense_indicator_pattern_type = "SHA256"
                    else:
                        sentinel_indicator_pattern_type = None

                else:
                    sentinel_indicator_pattern_type = None

            else:
                sentinel_indicator_pattern_type = None

            return sentinel_indicator_pattern_type, cofense_indicator_pattern_type

        except CofenseException as error:
            raise CofenseException(error)

    def create_indicator(
        self,
        indicators,
        cofense_object,
        cofense_indicator_pattern_type,
        indicator_source,
    ):
        """To create indicators into cofense triage.

        Args:
            indicator (JSON Dictionary): Indicator data in json.
            cofense_object (Class Object): class object of CofenseTriage class.
            cofense_indicator_pattern_type (String): threat type for creating indicator in cofense triage.
            indicator_source (String): source for creating indicator in cofense triage.

        Raises:
            CofenseException: Custom exception raises while getting exception.

        Returns:
            API Response: API response for create indicator call.
        """
        try:
            # Convert confidence integer to Level of threat (Malicious, Suspicious, or Benign).
            confidence = int(indicators.get("properties", "").get("confidence", "0"))
            if confidence >= 0 and confidence <= 33:
                threat_level = "Benign"
            elif confidence > 33 and confidence <= 66:
                threat_level = "Suspicious"
            else:
                threat_level = "Malicious"

            # get the threat value from the sentinel indicator data.
            threat_value = (
                indicators.get("properties", "").get("pattern", "").split("=")[1]
            ).strip("' ]")

            # Enter
            indicator_source = SENTINEL_SOURCE_PREFIX + indicator_source

            # Posting indicator into cofense triage.
            post_response = cofense_object.post_indicators(
                threat_level=threat_level,
                threat_type=cofense_indicator_pattern_type,
                threat_value=threat_value,
                threat_source=indicator_source,
                sentinel_indicator_name_post=indicators.get("name")
            )
            return post_response
        except CofenseException as error:
            raise CofenseException(error)

    def update_indicator(self, indicators, cofense_object, sentinel_cofense_id_table):
        """To update the indicator threat level in cofense triage.

        Args:
            indicator (JSON Dictionary): Indicator data in json.
            cofense_object (Class Object): class object of CofenseTriage class.
            sentinel_cofense_id_table (Dictionary): To get the cofense id for updating indicator.

        Raises:
            CofenseException: Custom exception raises while getting exception.
        """
        try:
            # get the cofense id from the id table.
            cofense_id = sentinel_cofense_id_table.get(indicators.get("name", ""))

            # Convert confidence integer to Level of threat (Malicious, Suspicious, or Benign).
            confidence = int(indicators.get("properties", "").get("confidence", "0"))
            if confidence >= 0 and confidence <= 33:
                threat_level = "Benign"
            elif confidence > 33 and confidence <= 67:
                threat_level = "Suspicious"
            else:
                threat_level = "Malicious"

            # Update the indicator data into cofense triage.
            cofense_object.update_indicators(
                threat_level=threat_level,
                id=cofense_id,
            )
        except CofenseException as error:
            raise CofenseException(error)


class CofenseTriage:
    """This class containes methods to create indicators into Cofense Triage."""

    def __init__(self) -> None:
        """Initialize instance variable for class."""
        self.access_token = auth_cofense(SENTINELTOCOFENSE)

        self.accept_content_type = "application/vnd.api+json"

        self.proxy = create_proxy()

    def post_indicators(self, threat_level, threat_type, threat_value, threat_source, sentinel_indicator_name_post):
        """To post indicators into cofense triage.

        Args:
            threat_level (String): (Required) Level of threat (Malicious, Suspicious, or Benign).
            threat_type (String): (Required) Type of threat (Hostname, URL, MD5 or SHA256).
            threat_value (String): (Required) Value corresponding to the type of threat indicated in threat_type.
            threat_source (String): (Required) Value corresponding to the source of the threat. Defaults to 'Triage-API' if not provided.
            sentinel_indicator_name_post (String): (Required) ID of sentinel indicator. Used in 422 error code.

        Raises:
            CofenseException: Custom exception raises while getting exception.

        Returns:
            post_indicator_json_response: API response to fetch the cofense indicator id.
        """
        try:
            __method_name = inspect.currentframe().f_code.co_name
            cofense_post_indicator_url = COFENSE_POST_INDICATOR_URL

            body = json.dumps(
                {
                    "data": {
                        "type": "threat_indicators",
                        "attributes": {
                            "threat_level": threat_level,
                            "threat_type": threat_type,
                            "threat_value": threat_value,
                            "threat_source": threat_source,
                        },
                    }
                }
            )

            headers = {
                "Accept": self.accept_content_type,
                "Content-Type": self.accept_content_type,
                "Authorization": "Bearer " + self.access_token,
            }

            retry_count_429 = 0
            retry_count_401 = 0
            while retry_count_429 < 3 and retry_count_401 < 3:
                post_indicator_response = make_rest_call(
                    url=cofense_post_indicator_url,
                    method="POST",
                    azure_function_name=SENTINELTOCOFENSE,
                    payload=body,
                    headers=headers,
                    proxies=self.proxy,
                )

                post_indicator_status_code = post_indicator_response.status_code

                # if response status code is 200-299.
                if (
                    post_indicator_status_code >= 200
                    and post_indicator_status_code <= 299
                ):
                    post_indicator_json_response = json.loads(
                        post_indicator_response.text
                    )
                    # return the json response to fetch the indicator id.
                    return post_indicator_status_code, post_indicator_json_response

                # if response status code is 401. access token expired.
                elif post_indicator_status_code == 401:
                    retry_count_401 = retry_count_401 + 1
                    applogger.error(
                        "{}(method={}) : {} : url: {}, Status Code : {}:  Error Reason: {}: "
                        " Sentinel access token expired, generating new access token. Retry count: {}.".format(
                            LOGS_STARTS_WITH,
                            __method_name,
                            SENTINELTOCOFENSE,
                            cofense_post_indicator_url,
                            post_indicator_response.status_code,
                            post_indicator_response.reason,
                            retry_count_401,
                        )
                    )
                    applogger.debug(
                        "{}(method={}) : {} : url: {}, Status Code : {}, Error Reason: {}, Response: {} :"
                        " Sentinel access token expired, generating new access token. Retry count: {}.".format(
                            LOGS_STARTS_WITH,
                            __method_name,
                            SENTINELTOCOFENSE,
                            cofense_post_indicator_url,
                            post_indicator_response.status_code,
                            post_indicator_response.reason,
                            post_indicator_response.text,
                            retry_count_401,
                        )
                    )
                    self.access_token = auth_cofense(SENTINELTOCOFENSE)

                # response status code is 429, to many request.
                elif post_indicator_status_code == 429:
                    applogger.error(
                        "{}(method={}) : {}: url: {}, Status Code : {} : "
                        "Getting 429 from cofense api call. Retrying again after {} seconds.".format(
                            LOGS_STARTS_WITH,
                            __method_name,
                            SENTINELTOCOFENSE,
                            cofense_post_indicator_url,
                            post_indicator_response.status_code,
                            COFENSE_429_SLEEP,
                        )
                    )
                    applogger.debug(
                        "{}(method={}) : {}: url: {}, Status Code : {}, Response reason: {}, Response: {} : "
                        "Getting 429 from cofense api call. Retry count: {}.".format(
                            LOGS_STARTS_WITH,
                            __method_name,
                            SENTINELTOCOFENSE,
                            cofense_post_indicator_url,
                            post_indicator_response.status_code,
                            post_indicator_response.reason,
                            post_indicator_response.text,
                            retry_count_429,
                        )
                    )
                    retry_count_429 += 1
                    time.sleep(COFENSE_429_SLEEP)

                # response status code is 422, If indicator already present in cofense triage.
                elif (
                    post_indicator_status_code == 422
                    and json.loads(post_indicator_response.text)
                    .get("errors")[0]
                    .get("title").strip()
                    == "has already been taken"
                ):
                    applogger.error(
                        "{}(method={}) : {}: url: {}, Status Code : {} : "
                        "Indicator already present in Cofense Triage. "
                        "Microsoft Sentinel Indicator ID: {} .".format(
                            LOGS_STARTS_WITH,
                            __method_name,
                            SENTINELTOCOFENSE,
                            cofense_post_indicator_url,
                            post_indicator_response.status_code,
                            sentinel_indicator_name_post,
                        )
                    )
                    applogger.debug(
                        "{}(method={}) : {}: url: {}, Status Code : {}, Response reason: {}, Response: {} :"
                        "Indicator already present in Cofense Triage."
                        "Microsoft Sentinel Indicator ID: {} .".format(
                            LOGS_STARTS_WITH,
                            __method_name,
                            SENTINELTOCOFENSE,
                            cofense_post_indicator_url,
                            post_indicator_response.status_code,
                            post_indicator_response.reason,
                            post_indicator_response.text,
                            sentinel_indicator_name_post
                        )
                    )
                    post_indicator_json_response = json.loads(
                        post_indicator_response.text
                    )
                    # return the json response to fetch the indicator id.
                    return post_indicator_status_code, post_indicator_json_response

                # if reponse status code is not 200-299, 401, 429 and 422(indicator already present).
                # Raise exception for this.
                else:
                    applogger.error(
                        "{}(method={}) : {} : url: {}, Status Code : {}: Error while creating indicators"
                        " into cofense triage. Error Reason: {}".format(
                            LOGS_STARTS_WITH,
                            __method_name,
                            SENTINELTOCOFENSE,
                            cofense_post_indicator_url,
                            post_indicator_response.status_code,
                            post_indicator_response.reason,
                        )
                    )
                    applogger.debug(
                        "{}(method={}) : {}: url: {}, Status Code : {}, Response reason: {}, Response: {} : "
                        "Error while creating indicators into cofense triage.".format(
                            LOGS_STARTS_WITH,
                            __method_name,
                            SENTINELTOCOFENSE,
                            cofense_post_indicator_url,
                            post_indicator_response.status_code,
                            post_indicator_response.reason,
                            post_indicator_response.text,
                        )
                    )
                    raise CofenseException(
                        "{}(method={}) : {} : Error while creating indicators into cofense triage."
                        " Error Reason: {}".format(
                            LOGS_STARTS_WITH,
                            __method_name,
                            SENTINELTOCOFENSE,
                            post_indicator_response.reason,
                        )
                    )
            applogger.error(
                "{}(method={}) : {} : Max retries exceeded for posting indicators into cofense.".format(
                    LOGS_STARTS_WITH, __method_name, SENTINELTOCOFENSE
                )
            )
            raise CofenseException(
                "{}(method={}) : {} : Max retries exceeded for posting indicators into cofense. Error Reason: {}".format(
                    LOGS_STARTS_WITH,
                    __method_name,
                    SENTINELTOCOFENSE,
                    post_indicator_response.reason,
                )
            )
        except CofenseException as error:
            raise CofenseException(error)

    def update_indicators(self, threat_level, id=""):
        """To update indicators into cofense triage.

        Args:
            threat_level (String): (Required) Level of threat (Malicious, Suspicious, or Benign).
            id (str, optional): Cofense Indicator ID for updating indicator.. Defaults to "".

        Raises:
            CofenseException: Custom exception raises while getting exception.

        Returns:
            update_indicator_json_response: API response to fetch the cofense indicator id.
        """
        try:
            __method_name = inspect.currentframe().f_code.co_name
            cofense_update_indicator_url = COFENSE_UPDATE_INDICATOR_URL + str(id)

            body = json.dumps(
                {
                    "data": {
                        "id": str(id),
                        "type": "threat_indicators",
                        "attributes": {
                            "threat_level": threat_level,
                        },
                    }
                }
            )

            headers = {
                "Accept": self.accept_content_type,
                "Content-Type": self.accept_content_type,
                "Authorization": "Bearer " + self.access_token,
            }

            retry_count_429 = 0
            retry_count_401 = 0
            while retry_count_429 < 3 and retry_count_401 < 3:
                update_indicator_response = make_rest_call(
                    url=cofense_update_indicator_url,
                    method="PUT",
                    azure_function_name=SENTINELTOCOFENSE,
                    payload=body,
                    headers=headers,
                    proxies=self.proxy,
                )

                update_indicator_status_code = update_indicator_response.status_code

                if (
                    update_indicator_status_code >= 200
                    and update_indicator_status_code <= 299
                ):
                    update_indicator_json_response = json.loads(
                        update_indicator_response.text
                    )
                    # return the json response to fetch the indicator id.
                    return update_indicator_json_response

                elif update_indicator_status_code == 401:
                    retry_count_401 = retry_count_401 + 1
                    applogger.error(
                        "{}(method={}) : {} : url: {}, Status Code : {}:  Error Reason: {}: "
                        " Sentinel access token expired, generating new access token. Retry count: {}.".format(
                            LOGS_STARTS_WITH,
                            __method_name,
                            SENTINELTOCOFENSE,
                            cofense_update_indicator_url,
                            update_indicator_response.status_code,
                            update_indicator_response.reason,
                            retry_count_401,
                        )
                    )
                    applogger.debug(
                        "{}(method={}) : {} : url: {}, Status Code : {}, Error Reason: {}, Response: {} :"
                        " Sentinel access token expired, generating new access token. Retry count: {}.".format(
                            LOGS_STARTS_WITH,
                            __method_name,
                            SENTINELTOCOFENSE,
                            cofense_update_indicator_url,
                            update_indicator_response.status_code,
                            update_indicator_response.reason,
                            update_indicator_response.text,
                            retry_count_401,
                        )
                    )
                    self.access_token = auth_cofense(SENTINELTOCOFENSE)

                elif update_indicator_status_code == 429:
                    applogger.error(
                        "{}(method={}) : {}: url: {}, Status Code : {} : "
                        "Getting 429 from cofense api call. Retrying again after {} seconds.".format(
                            LOGS_STARTS_WITH,
                            __method_name,
                            SENTINELTOCOFENSE,
                            cofense_update_indicator_url,
                            update_indicator_response.status_code,
                            COFENSE_429_SLEEP,
                        )
                    )
                    applogger.debug(
                        "{}(method={}) : {}: url: {}, Status Code : {}, Response reason: {}, Response: {} : "
                        "Getting 429 from cofense api call. Retry count: {}.".format(
                            LOGS_STARTS_WITH,
                            __method_name,
                            SENTINELTOCOFENSE,
                            cofense_update_indicator_url,
                            update_indicator_response.status_code,
                            update_indicator_response.reason,
                            update_indicator_response.text,
                            retry_count_429,
                        )
                    )
                    retry_count_429 += 1
                    time.sleep(COFENSE_429_SLEEP)

                else:
                    applogger.error(
                        "{}(method={}) : {} : url: {}, Status Code : {}: Error while updating indicators"
                        " into cofense triage. Error Reason: {}".format(
                            LOGS_STARTS_WITH,
                            __method_name,
                            SENTINELTOCOFENSE,
                            cofense_update_indicator_url,
                            update_indicator_response.status_code,
                            update_indicator_response.reason,
                        )
                    )
                    applogger.debug(
                        "{}(method={}) : {}: url: {}, Status Code : {}, Response reason: {}, Response: {} : "
                        "Error while creating indicators into cofense triage.".format(
                            LOGS_STARTS_WITH,
                            __method_name,
                            SENTINELTOCOFENSE,
                            cofense_update_indicator_url,
                            update_indicator_response.status_code,
                            update_indicator_response.reason,
                            update_indicator_response.text,
                        )
                    )
                    raise CofenseException(
                        "{}(method={}) : {} : Error while updating indicators into cofense triage."
                        " Error Reason: {}".format(
                            LOGS_STARTS_WITH,
                            __method_name,
                            SENTINELTOCOFENSE,
                            update_indicator_response.reason,
                        )
                    )
            applogger.error(
                "{}(method={}) : {} : Max retries exceeded for updating indicators into cofense.".format(
                    LOGS_STARTS_WITH, __method_name, SENTINELTOCOFENSE
                )
            )
            raise CofenseException(
                "{}(method={}) : {} : Max retries exceeded for updating indicators into cofense. Error Reason: {}".format(
                    LOGS_STARTS_WITH,
                    __method_name,
                    SENTINELTOCOFENSE,
                    update_indicator_response.reason,
                )
            )
        except CofenseException as error:
            raise CofenseException(error)
