"""This file contains implementation of cofense indicator fetching and creating microsoft indicator."""
import time
import json
import inspect
from ..SharedCode.consts import (
    AZURE_SUBSCRIPTION_ID,
    AZURE_RESOURCE_GROUP,
    AZURE_WORKSPACE_NAME,
    CREATE_SENTINEL_INDICATORS_URL,
    LOGS_STARTS_WITH,
    COFENSE_BASE_URL,
    ENDPOINTS,
    CONNECTION_STRING,
    AZURE_FUNCTION_Name1,
    COFENSE_SOURCE_PREFIX,
    SENTINEL_SOURCE_PREFIX,
)
from ..SharedCode.logger import applogger
from ..SharedCode.cofense_exception import CofenseException
from ..SharedCode.state_manager import StateManager
from ..SharedCode.utils import (
    auth_sentinel,
    make_rest_call,
    auth_cofense,
    check_environment_var_exist,
    create_proxy,
)


class MicrosoftSentinel:
    """This class contains methods to create indicator into Microsoft Sentinel."""

    def __init__(self):
        """Initialize instance variable for class."""
        self.bearer_token = auth_sentinel(AZURE_FUNCTION_Name1)

    def create_indicator(self, indicator_data):
        """To create indicator into Microsoft Sentinel."""
        __method_name = inspect.currentframe().f_code.co_name
        try:
            retry_count_429 = 0
            retry_count_401 = 0
            while retry_count_429 < 3 and retry_count_401 < 3:
                create_indicator_url = CREATE_SENTINEL_INDICATORS_URL.format(
                    subscriptionId=AZURE_SUBSCRIPTION_ID,
                    resourceGroupName=AZURE_RESOURCE_GROUP,
                    workspaceName=AZURE_WORKSPACE_NAME,
                )
                headers = {
                    "Content-Type": "application/json",
                    "Authorization": "Bearer {}".format(self.bearer_token),
                }
                response = make_rest_call(
                    url=create_indicator_url,
                    method="POST",
                    azure_function_name=AZURE_FUNCTION_Name1,
                    payload=json.dumps(indicator_data),
                    headers=headers,
                )
                if response.status_code >= 200 and response.status_code <= 299:
                    response_json = response.json()
                    applogger.debug(
                        "{}(method={}) : {} : Created the indicator into the sentinel with status code {}"
                        " and got the response {}".format(
                            LOGS_STARTS_WITH,
                            __method_name,
                            AZURE_FUNCTION_Name1,
                            response.status_code,
                            response_json,
                        )
                    )
                    return
                elif response.status_code == 429:
                    applogger.error(
                        "{}(method={}) : {} : trying again error 429.".format(
                            LOGS_STARTS_WITH, __method_name, AZURE_FUNCTION_Name1
                        )
                    )
                    retry_count_429 += 1
                    time.sleep(5)
                elif response.status_code == 401:
                    applogger.error(
                        "{}(method={}) : {} : trying again error 401.".format(
                            LOGS_STARTS_WITH, __method_name, AZURE_FUNCTION_Name1
                        )
                    )
                    self.bearer_token = auth_sentinel(AZURE_FUNCTION_Name1)
                    headers["Authorization"] = ("Bearer {}".format(self.bearer_token),)
                    retry_count_401 += 1
                else:
                    applogger.error(
                        "{}(method={}) : {} : url: {}, Status Code : {}: Error while creating microsoft"
                        " sentinel access_token. Error Reason: {}".format(
                            LOGS_STARTS_WITH,
                            __method_name,
                            AZURE_FUNCTION_Name1,
                            create_indicator_url,
                            response.status_code,
                            response.reason,
                        )
                    )
                    raise CofenseException(
                        "{}(method={}) : {} : url: {}, Status Code : {}: Error while creating microsoft"
                        " sentinel access_token. Error Reason: {}".format(
                            LOGS_STARTS_WITH,
                            __method_name,
                            AZURE_FUNCTION_Name1,
                            create_indicator_url,
                            response.status_code,
                            response.reason,
                        )
                    )
            applogger.error(
                "{}(method={}) : {} : Max retries exceeded for microsoft sentinel.".format(
                    LOGS_STARTS_WITH, __method_name, AZURE_FUNCTION_Name1
                )
            )
            raise CofenseException(
                "{}(method={}) : {} : Max retries exceeded for microsoft sentinel.".format(
                    LOGS_STARTS_WITH, __method_name, AZURE_FUNCTION_Name1
                )
            )
        except CofenseException as error:
            applogger.error(
                "{}(method={}) : {} : Error generated while getting sentinel access token :{}".format(
                    LOGS_STARTS_WITH, __method_name, AZURE_FUNCTION_Name1, error
                )
            )
            raise CofenseException(
                "{}(method={}) : {} : Error generated while getting sentinel access token :{}".format(
                    LOGS_STARTS_WITH, __method_name, AZURE_FUNCTION_Name1, error
                )
            )


class CofenseTriage:
    """This class contains methods to pull the data from cofense apis and transform it to create TI indicator."""

    def __init__(self):
        """Initialize instance variable for class."""
        self.access_token = auth_cofense(AZURE_FUNCTION_Name1)
        self.proxy = create_proxy()
        self.microsoft_obj = MicrosoftSentinel()
        self.state_obj = StateManager(
            connection_string=CONNECTION_STRING, file_path="cofense"
        )
        self.headers = {
            "Accept": "application/vnd.api+json",
            "Content-Type": "application/vnd.api+json",
            "Authorization": "Bearer " + self.access_token,
        }

    def get_indicators_from_cofense(self, url, params):
        """Pull the cofense indicators from REST APIs of Cofense."""
        __method_name = inspect.currentframe().f_code.co_name
        try:
            retry_count_429 = 0
            retry_count_401 = 0
            while retry_count_429 < 3 and retry_count_401 < 3:
                indicators_data = make_rest_call(
                    url=url,
                    method="GET",
                    azure_function_name=AZURE_FUNCTION_Name1,
                    params=params,
                    headers=self.headers,
                    proxies=self.proxy,
                )
                indicators_data_status_code = indicators_data.status_code
                if (
                    indicators_data_status_code >= 200
                    and indicators_data_status_code <= 299
                ):
                    indicator_json = indicators_data.json()
                    return indicator_json
                elif indicators_data_status_code == 401:
                    applogger.error(
                        "{}(method={}) : {} : trying again error 401.".format(
                            LOGS_STARTS_WITH, __method_name, AZURE_FUNCTION_Name1
                        )
                    )
                    self.access_token = auth_cofense(AZURE_FUNCTION_Name1)
                    self.headers["Authorization"] = "Bearer " + self.access_token
                    retry_count_401 += 1
                elif indicators_data_status_code == 429:
                    applogger.error(
                        "{}(method={}) : {} : trying again error 429.".format(
                            LOGS_STARTS_WITH, __method_name, AZURE_FUNCTION_Name1
                        )
                    )
                    retry_count_429 += 1
                    time.sleep(5)
                else:
                    applogger.error(
                        "{}(method={}) : {} : url: {}, Status Code : {} : error"
                        " while pulling indicator data.".format(
                            LOGS_STARTS_WITH,
                            __method_name,
                            AZURE_FUNCTION_Name1,
                            url,
                            indicators_data_status_code,
                        )
                    )
                    raise CofenseException(
                        "{}(method={}) : {} : url: {}, Status Code : {} : error"
                        " while pulling indicator data.".format(
                            LOGS_STARTS_WITH,
                            __method_name,
                            AZURE_FUNCTION_Name1,
                            url,
                            indicators_data_status_code,
                        )
                    )
            applogger.error(
                "{}(method={}) : {} : Max retries exceeded for fetching data.".format(
                    LOGS_STARTS_WITH, __method_name, AZURE_FUNCTION_Name1
                )
            )
            raise CofenseException(
                "{}(method={}) : {} : Max retries exceeded for fetching data.".format(
                    LOGS_STARTS_WITH, __method_name, AZURE_FUNCTION_Name1
                )
            )
        except CofenseException as error:
            applogger.error(
                "{}(method={}) : {} : error while pulling data of indicator : {}".format(
                    LOGS_STARTS_WITH, __method_name, AZURE_FUNCTION_Name1, error
                )
            )
            raise CofenseException(
                "{}(method={}) : {} : error while pulling data of indicator : {}".format(
                    LOGS_STARTS_WITH, __method_name, AZURE_FUNCTION_Name1, error
                )
            )

    def threat_level_mapping(self, indicator):
        """To map threat level with confidence for microsoft sentinel indicator data."""
        __method_name = inspect.currentframe().f_code.co_name
        threat_level = indicator.get("attributes", {}).get("threat_level")
        if threat_level == "Benign":
            threat_level = 1
        elif threat_level == "Suspicious":
            threat_level = 75
        elif threat_level == "Malicious":
            threat_level = 100
        else:
            applogger.error(
                "{}(method={}) : {} : Unknown threat type.".format(
                    LOGS_STARTS_WITH, __method_name, AZURE_FUNCTION_Name1
                )
            )
            raise CofenseException(
                "{}(method={}) : {} : Unknown threat type.".format(
                    LOGS_STARTS_WITH, __method_name, AZURE_FUNCTION_Name1
                )
            )
        return threat_level

    def source_mapping(self, indicator):
        """To map cofense source with sentinel source for microsoft sentinel indicator data."""
        response_source = indicator.get("attributes", {}).get("threat_source")
        splitted_source = response_source.split(":")
        source = None
        if (
            splitted_source[0].lower().strip()
            != SENTINEL_SOURCE_PREFIX.split(":")[0].lower().strip()
        ):
            source = COFENSE_SOURCE_PREFIX + response_source
        return source

    def pattern_type_mapping(self, indicator_threat_type):
        """To map threat type with patternType for microsoft sentinel indicator data."""
        threat_type = ""
        if indicator_threat_type == "URL":
            threat_type = "url"
        elif indicator_threat_type == "Hostname":
            threat_type = "domain-name"
        elif indicator_threat_type == "SHA256" or indicator_threat_type == "MD5":
            threat_type = "file"
        return threat_type

    def pattern_mapping(
        self, threat_type, indicator_threat_value, indicator_threat_type
    ):
        """To map threat value with pattern for microsoft sentinel indicator data."""
        pattern = ""
        if threat_type == "url":
            indicator_threat_value_url = (
                indicator_threat_value.replace("\\n", "").replace("\\r", "").replace("\\u", "").replace("\\", "")
            )
            pattern = "[url:value = '{}']".format(indicator_threat_value_url)
        elif threat_type == "domain-name":
            pattern = "[domain-name:value = '{}']".format(indicator_threat_value)
        elif threat_type == "file":
            if indicator_threat_type == "SHA256":
                pattern = "[file:hashes.'SHA-256' = '{}']".format(
                    indicator_threat_value
                )
            elif indicator_threat_type == "MD5":
                pattern = "[file:hashes.'MD5' = '{}']".format(indicator_threat_value)
        return pattern

    def name_mapping(self, indicator):
        """To map cofense owner name with createdBy for microsoft sentinel indicator data."""
        __method_name = inspect.currentframe().f_code.co_name
        owner_link = (
            indicator.get("relationships", {})
            .get("owner", {})
            .get("links", {})
            .get("related", "")
        )
        name = ""
        if owner_link:
            response_owner = self.get_indicators_from_cofense(
                url=owner_link, params=None
            )
            owner_attributes = response_owner.get("data", {}).get("attributes", {})
            owner_attributes_fname = owner_attributes.get("first_name", "")
            owner_attributes_lname = owner_attributes.get("last_name", "")
            owner_attributes_name = owner_attributes.get("name", "")
            if owner_attributes:
                if owner_attributes_fname or owner_attributes_lname:
                    name = "{} {}".format(
                        owner_attributes_fname, owner_attributes_lname
                    )
                elif owner_attributes_name:
                    name = owner_attributes_name
                else:
                    applogger.error(
                        "{}(method={}) : {} : no name found in the owner link.".format(
                            LOGS_STARTS_WITH, __method_name, AZURE_FUNCTION_Name1
                        )
                    )
            else:
                applogger.error(
                    "{}(method={}) : {} : no attributes found in the owner link.".format(
                        LOGS_STARTS_WITH, __method_name, AZURE_FUNCTION_Name1
                    )
                )
        else:
            applogger.error(
                "{}(method={}) : {} : no owner link found in the indicator.".format(
                    LOGS_STARTS_WITH, __method_name, AZURE_FUNCTION_Name1
                )
            )
        return name

    def data_mapping(self):
        """To map cofense data to microsoft sentinel indicator data."""
        __method_name = inspect.currentframe().f_code.co_name
        try:
            check_environment_var_exist(AZURE_FUNCTION_Name1)
            list_indicator_url = "{}{}".format(COFENSE_BASE_URL, ENDPOINTS["get_lists"])
            params = {"page[number]": 1, "page[size]": 200, "sort": "updated_at"}
            last_checkpoint = self.state_obj.get()
            if last_checkpoint is not None:
                params["filter[updated_at_gteq]"] = last_checkpoint
                applogger.debug(
                    "{}(method={}) : {} : last checkpoint is {}".format(
                        LOGS_STARTS_WITH,
                        __method_name,
                        AZURE_FUNCTION_Name1,
                        last_checkpoint,
                    )
                )
            applogger.debug(
                "{}(method={}) : {} : when getting indicators URL: {}, headers: {}".format(
                    LOGS_STARTS_WITH,
                    __method_name,
                    AZURE_FUNCTION_Name1,
                    list_indicator_url,
                    self.headers,
                )
            )
            data_count = 0
            while True:
                indicators_data_json = self.get_indicators_from_cofense(
                    url=list_indicator_url, params=params
                )
                indicator_data = indicators_data_json.get("data", [])
                for indicator in indicator_data:
                    checkpoint = indicator.get("attributes", {}).get("updated_at", "")
                    data = {"kind": "indicator"}
                    data["properties"] = {}

                    source_cofence = self.source_mapping(indicator)
                    if source_cofence:
                        data["properties"]["source"] = source_cofence
                    else:
                        applogger.debug(
                            "{}(method={}) : {} : skipping the sentinel indicator.".format(
                                LOGS_STARTS_WITH,
                                __method_name,
                                AZURE_FUNCTION_Name1,
                            )
                        )
                        data = {}
                        continue

                    data["properties"]["externalId"] = indicator.get("id", "")
                    data["properties"]["displayName"] = "Cofense Triage : {}".format(
                        indicator.get("id", "")
                    )
                    threat_level = self.threat_level_mapping(indicator)
                    data["properties"]["confidence"] = threat_level

                    indicator_threat_type = indicator.get("attributes", {}).get(
                        "threat_type"
                    )
                    threat_type = self.pattern_type_mapping(indicator_threat_type)

                    if threat_type:
                        data["properties"]["patternType"] = threat_type
                    else:
                        applogger.debug(
                            "{}(method={}) : {} : skipping the threat type {}".format(
                                LOGS_STARTS_WITH,
                                __method_name,
                                AZURE_FUNCTION_Name1,
                                indicator_threat_type,
                            )
                        )
                        data = {}
                        continue
                    data["properties"]["threatTypes"] = [threat_type]
                    indicator_threat_value = indicator.get("attributes", {}).get(
                        "threat_value"
                    )
                    pattern = self.pattern_mapping(
                        threat_type, indicator_threat_value, indicator_threat_type
                    )
                    if pattern:
                        data["properties"]["pattern"] = pattern
                    else:
                        applogger.debug(
                            "{}(method={}) : {} : skipping the threat type {}".format(
                                LOGS_STARTS_WITH,
                                __method_name,
                                AZURE_FUNCTION_Name1,
                                indicator_threat_type,
                            )
                        )
                        data = {}
                        continue
                    data["properties"]["created"] = indicator.get("attributes", {}).get(
                        "created_at"
                    )
                    owner_name = self.name_mapping(indicator)
                    if owner_name:
                        data["properties"]["createdByRef"] = owner_name
                    data["properties"]["externalLastUpdatedTimeUtc"] = indicator.get(
                        "attributes", {}
                    ).get("updated_at")
                    data_count += 1
                    self.microsoft_obj.create_indicator(data)
                    data = {}
                    break
                self.state_obj.post(str(checkpoint))
                applogger.debug(
                    "{}(method={}) : {} : checkpoint saved {}".format(
                        LOGS_STARTS_WITH,
                        __method_name,
                        AZURE_FUNCTION_Name1,
                        checkpoint,
                    )
                )
                if not indicators_data_json.get("links", {}).get("next", ""):
                    break
                params["page[number]"] += 1
            applogger.info(
                "{}(method={}) : {} : created total {} indicators into sentinel.".format(
                    LOGS_STARTS_WITH, __method_name, AZURE_FUNCTION_Name1, data_count
                )
            )
        except CofenseException as error:
            raise CofenseException(error)
