"""This file contains implementation of mapping of cofense data to sentinel indicator."""
import json
import inspect
import datetime
from .sentinel import MicrosoftSentinel
from ..SharedCode.consts import (
    LOGS_STARTS_WITH,
    COFENSE_BASE_URL,
    ENDPOINTS,
    CONNECTION_STRING,
    COFENSE_TO_SENTINEL,
    COFENSE_SOURCE_PREFIX,
    SENTINEL_SOURCE_PREFIX,
    REPORTS_TABLE_NAME,
    COFENSE_PAGE_NUMBER,
    COFENSE_PAGE_SIZE,
)
from ..SharedCode.logger import applogger
from ..SharedCode.cofense_exception import CofenseException
from ..SharedCode.state_manager import StateManager
from ..SharedCode.utils import check_environment_var_exist
from .cofense import CofenseTriage

class CofenseToSentinelMapping:
    """This class contains methods to pull the data from cofense apis and transform it to create TI indicator."""

    def __init__(self):
        """Initialize instance variable for class."""
        self.cofense_triage_obj = CofenseTriage()
        self.microsoft_obj = MicrosoftSentinel()
        self.log_type = REPORTS_TABLE_NAME
        self.state_obj = StateManager(
            connection_string=CONNECTION_STRING, file_path="cofense"
        )

    def threat_level_mapping(self, indicator):
        """To map threat level with confidence for microsoft sentinel indicator data."""
        __method_name = inspect.currentframe().f_code.co_name
        threat_level = indicator.get("attributes", {}).get("threat_level")
        if threat_level == "Benign":
            threat_level = 1
        elif threat_level == "Suspicious":
            threat_level = 75
        elif threat_level == "Malicious":
            threat_level = 100
        else:
            applogger.error(
                "{}(method={}) : {} : Unknown threat type.".format(
                    LOGS_STARTS_WITH, __method_name, COFENSE_TO_SENTINEL
                )
            )
            raise CofenseException(
                "{}(method={}) : {} : Unknown threat type.".format(
                    LOGS_STARTS_WITH, __method_name, COFENSE_TO_SENTINEL
                )
            )
        return threat_level

    def source_mapping(self, indicator):
        """To map cofense source with sentinel source for microsoft sentinel indicator data."""
        response_source = indicator.get("attributes", {}).get("threat_source")
        splitted_source = response_source.split(":")
        source = None
        if (
            splitted_source[0].lower().strip()
            != SENTINEL_SOURCE_PREFIX.split(":")[0].lower().strip()
        ):
            source = COFENSE_SOURCE_PREFIX + response_source
        return source

    def pattern_type_mapping(self, indicator_threat_type):
        """To map threat type with patternType for microsoft sentinel indicator data."""
        threat_type = ""
        if indicator_threat_type == "URL":
            threat_type = "url"
        elif indicator_threat_type == "Hostname":
            threat_type = "domain-name"
        elif indicator_threat_type == "SHA256" or indicator_threat_type == "MD5":
            threat_type = "file"
        return threat_type

    def pattern_mapping(
        self, threat_type, indicator_threat_value, indicator_threat_type
    ):
        """To map threat value with pattern for microsoft sentinel indicator data."""
        pattern = ""
        if threat_type == "url":
            indicator_threat_value_url = (
                indicator_threat_value.replace("\\n", "").replace("\\r", "").replace("\\u", "").replace("\\", "")
            )
            pattern = "[url:value = '{}']".format(indicator_threat_value_url)
        elif threat_type == "domain-name":
            pattern = "[domain-name:value = '{}']".format(indicator_threat_value)
        elif threat_type == "file":
            if indicator_threat_type == "SHA256":
                pattern = "[file:hashes.'SHA-256' = '{}']".format(
                    indicator_threat_value
                )
            elif indicator_threat_type == "MD5":
                pattern = "[file:hashes.'MD5' = '{}']".format(indicator_threat_value)
        return pattern

    def name_mapping(self, indicator):
        """To map cofense owner name with createdBy for microsoft sentinel indicator data."""
        __method_name = inspect.currentframe().f_code.co_name
        owner_link = (
            indicator.get("relationships", {})
            .get("owner", {})
            .get("links", {})
            .get("related", "")
        )
        name = ""
        if owner_link:
            response_owner = self.cofense_triage_obj.get_indicators_from_cofense(
                url=owner_link, params=None
            )
            owner_data = response_owner.get("data", {})
            if owner_data:
                owner_attributes = owner_data.get("attributes", {})
                owner_attributes_fname = owner_attributes.get("first_name", "")
                owner_attributes_lname = owner_attributes.get("last_name", "")
                owner_attributes_name = owner_attributes.get("name", "")
                if owner_attributes:
                    if owner_attributes_fname or owner_attributes_lname:
                        name = "{} {}".format(
                            owner_attributes_fname, owner_attributes_lname
                        )
                    elif owner_attributes_name:
                        name = owner_attributes_name
                    else:
                        applogger.error(
                            "{}(method={}) : {} : no name found in the owner link.".format(
                                LOGS_STARTS_WITH, __method_name, COFENSE_TO_SENTINEL
                            )
                        )
            else:
                applogger.error(
                    "{}(method={}) : {} : no data found in the owner link.".format(
                        LOGS_STARTS_WITH, __method_name, COFENSE_TO_SENTINEL
                    )
                )
        else:
            applogger.error(
                "{}(method={}) : {} : no owner link found in the indicator.".format(
                    LOGS_STARTS_WITH, __method_name, COFENSE_TO_SENTINEL
                )
            )
        return name

    def report_link_mapping(self, indicator):
        """To get the report link from the cofense indicator."""
        report_link = (
            indicator.get("relationships", {})
            .get("reports", {})
            .get("links", {})
            .get("related", "")
        )
        return report_link

    # def report_tag_mapping(self, indicator):
    #     """To map reports tag to threatIndicatorTags for microsoft sentinel indicator data."""
    #     __method_name = inspect.currentframe().f_code.co_name
    #     report_link = (
    #         indicator.get("relationships", {})
    #         .get("reports", {})
    #         .get("links", {})
    #         .get("related", "")
    #     )
    #     tags = []
    #     if report_link:
    #         response_report = self.cofense_triage_obj.get_indicators_from_cofense(
    #             url=report_link, params=None
    #         )
    #         response_report_data = response_report.get("data", [])
    #         if response_report_data:
    #             for report in response_report_data:
    #                 report_tags = report.get("attributes", {}).get("tags", [])
    #                 tags.extend(report_tags)
    #             set_tags = set(tags)
    #             tags = list(set_tags)
    #         else:
    #             applogger.error(
    #                 "{}(method={}) : {} : no report data found in the indicator.".format(
    #                     LOGS_STARTS_WITH, __method_name, COFENSE_TO_SENTINEL
    #                 )
    #             )
    #     else:
    #         applogger.error(
    #             "{}(method={}) : {} : no report link found in the indicator.".format(
    #                 LOGS_STARTS_WITH, __method_name, COFENSE_TO_SENTINEL
    #             )
    #         )
    #     return tags  

    def data_mapping(self, indicator_data):
        """To map the data and create indicators into sentinel."""
        __method_name = inspect.currentframe().f_code.co_name
        report_data = []
        checkpoint = ""
        for indicator in indicator_data:
            checkpoint = indicator.get("attributes", {}).get("updated_at", "")
            data = {"kind": "indicator"}
            data["properties"] = {}

            source_cofence = self.source_mapping(indicator)
            if source_cofence:
                data["properties"]["source"] = source_cofence
            else:
                applogger.debug(
                    "{}(method={}) : {} : skipping the sentinel indicator.".format(
                        LOGS_STARTS_WITH,
                        __method_name,
                        COFENSE_TO_SENTINEL,
                    )
                )
                data = {}
                continue

            data["properties"]["externalId"] = indicator.get("id", "")
            data["properties"]["displayName"] = "Cofense Triage : {}".format(
                indicator.get("id", "")
            )
            threat_level = self.threat_level_mapping(indicator)
            data["properties"]["confidence"] = threat_level

            indicator_threat_type = indicator.get("attributes", {}).get(
                "threat_type"
            )
            threat_type = self.pattern_type_mapping(indicator_threat_type)

            if threat_type:
                data["properties"]["patternType"] = threat_type
            else:
                applogger.debug(
                    "{}(method={}) : {} : skipping the threat type {}".format(
                        LOGS_STARTS_WITH,
                        __method_name,
                        COFENSE_TO_SENTINEL,
                        indicator_threat_type,
                    )
                )
                data = {}
                continue
            data["properties"]["threatTypes"] = [threat_type]
            indicator_threat_value = indicator.get("attributes", {}).get(
                "threat_value"
            )
            pattern = self.pattern_mapping(
                threat_type, indicator_threat_value, indicator_threat_type
            )
            if pattern:
                data["properties"]["pattern"] = pattern
            else:
                applogger.debug(
                    "{}(method={}) : {} : skipping the threat type {}".format(
                        LOGS_STARTS_WITH,
                        __method_name,
                        COFENSE_TO_SENTINEL,
                        indicator_threat_type,
                    )
                )
                data = {}
                continue
            data["properties"]["created"] = indicator.get("attributes", {}).get(
                "created_at"
            )
            owner_name = self.name_mapping(indicator)
            if owner_name:
                data["properties"]["createdByRef"] = owner_name
            data["properties"]["externalLastUpdatedTimeUtc"] = indicator.get(
                "attributes", {}
            ).get("updated_at")
            # data["properties"]["threatIntelligenceTags"] = self.report_tag_mapping(indicator)
            report_link = self.report_link_mapping(indicator)
            if report_link:
                applogger.debug(
                    "{}(method={}) : {} : report link : {}".format(
                        LOGS_STARTS_WITH,
                        __method_name,
                        COFENSE_TO_SENTINEL,
                        report_link,
                    )
                )
            else:
                applogger.error(
                    "{}(method={}) : {} : no report link found.".format(
                        LOGS_STARTS_WITH, __method_name, COFENSE_TO_SENTINEL
                    )
                )
            sentinel_indicator_response = self.microsoft_obj.create_indicator(
                data
            )
            reportdata = {
                "name": sentinel_indicator_response.get("name", ""),
                "report_link": report_link,
            }
            report_data.append(reportdata)
            data = {}
        return report_data, checkpoint

    def create_sentinel_indicator(self):
        """To map cofense data to microsoft sentinel indicator data."""
        __method_name = inspect.currentframe().f_code.co_name
        try:
            check_environment_var_exist(COFENSE_TO_SENTINEL)
            list_indicator_url = "{}{}".format(COFENSE_BASE_URL, ENDPOINTS["get_lists"])
            params = {"page[number]": COFENSE_PAGE_NUMBER, "page[size]": COFENSE_PAGE_SIZE, "sort": "updated_at"}
            last_checkpoint = self.state_obj.get(COFENSE_TO_SENTINEL)
            if last_checkpoint is not None:
                params["filter[updated_at_gteq]"] = last_checkpoint
                applogger.debug(
                    "{}(method={}) : {} : last checkpoint is {}".format(
                        LOGS_STARTS_WITH,
                        __method_name,
                        COFENSE_TO_SENTINEL,
                        last_checkpoint,
                    )
                )
            # else:
            #     today_datetime = datetime.datetime.utcnow() - datetime.timedelta(days=15)
            #     from_datetime = datetime.datetime.strftime(today_datetime, '%Y-%m-%dT%H:%M:%S.%fZ')
            #     params["filter[updated_at_gteq]"] = from_datetime
            #     applogger.debug(
            #         "{}(method={}) : {} : getting indicators data of last 15 days from {}".format(
            #             LOGS_STARTS_WITH,
            #             __method_name,
            #             COFENSE_TO_SENTINEL,
            #             from_datetime,
            #         )
            #     )
            applogger.debug(
                "{}(method={}) : {} : when getting indicators URL: {}, headers: {}".format(
                    LOGS_STARTS_WITH,
                    __method_name,
                    COFENSE_TO_SENTINEL,
                    list_indicator_url,
                    self.cofense_triage_obj.headers,
                )
            )
            while True:
                indicators_data_json = self.cofense_triage_obj.get_indicators_from_cofense(
                    url=list_indicator_url, params=params
                )
                indicator_data = indicators_data_json.get("data", [])
                if indicator_data:
                    report_data, checkpoint = self.data_mapping(indicator_data)
                    if report_data and checkpoint:
                        self.microsoft_obj.post_data(json.dumps(report_data), self.log_type)
                        self.state_obj.post(str(checkpoint))
                    applogger.debug(
                        "{}(method={}) : {} : checkpoint saved {}".format(
                            LOGS_STARTS_WITH,
                            __method_name,
                            COFENSE_TO_SENTINEL,
                            checkpoint,
                        )
                    )
                    if not indicators_data_json.get("links", {}).get("next", ""):
                        break
                    params["page[number]"] += 1
                else:
                    applogger.error(
                        "{}(method={}) : {} : no indicator data found.".format(
                            LOGS_STARTS_WITH, __method_name, COFENSE_TO_SENTINEL
                        )
                    )
        except CofenseException as error:
            raise CofenseException(error)
